<?php
// config.php — réglages globaux du MVP blockchain
define('CHAIN_DIFFICULTY', 3);            // difficulté PoW (3-4 pour démo)
define('APP_TIMEZONE', 'Europe/Zurich');  // cohérence des timestamps
date_default_timezone_set(APP_TIMEZONE);

// Optionnel si vous voulez limiter le CORS des endpoints API
define('ALLOW_ORIGIN', '*');
